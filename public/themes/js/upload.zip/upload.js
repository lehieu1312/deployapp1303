//var ejs = require('ejs');

$('.upload-btn').on('click', function() {
    $('#upload-input').click();
    $('.progress-bar').text('0%');
    $('.progress-bar').width('0%');
});

function formatBytes(a, b) {
    if (0 == a) return "0 Bytes";
    var c = 1e3,
        d = b || 2,
        e = ["Bytes", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB"],
        f = Math.floor(Math.log(a) / Math.log(c));
    return parseFloat((a / Math.pow(c, f)).toFixed(d)) + " " + e[f]
}
$('#upload-input').on('change', function() {

    var files = $(this).get(0).files;

    if (files.length > 0) {
        // create a FormData object which will be sent as the data payload in the
        // AJAX request
        var formData = new FormData();

        // loop through all the selected files and add them to the formData object
        for (var i = 0; i < files.length; i++) {
            var file = files[i];
            // add the files to formData object for the data payload
            formData.append('uploads', file, file.name);
        }
        $('.icon-upload').removeClass('fa-cloud-upload').addClass('fa-file-archive-o');
        $('.around-upload').find('.file-head').html(file.name);
        alert(file.size);
        $('.around-upload').find('.file-body').html(formatBytes(file.size));
        if (file.size > 150000000) {
            $("#danger-alert").delay(4000).slideUp(200, function() {
                $(this).alert();
            });
            // $('.form-group').find('.help-block').html('Upload file size is too large');
            // $('.form-group').removeClass('has-success').addClass('has-error');
            $("#danger-alert").fadeTo(2000, 500).slideUp(500, function() {
                $('alert-upload').html('Upload file size is too large');
                $("#danger-alert").slideUp(500);
            });
        } else if (file.name.split('.').pop() != 'zip') {
            $('.form-group').find('.help-block').html('File upload is not zip format');
            $('.form-group').removeClass('has-success').addClass('has-error');
        } else {
            $('.form-group').find('.help-block').html('');
            $('.form-group').removeClass('has-error').addClass('has-success');
            $('.upload-btn').hide();
            $('.progress').show();
            $.ajax({
                url: '/upload',
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                datatype: "json",
                success: function(data) {
                    // alert(data);
                    if (data.status == 2) {
                        location.href = '/infoapp'
                    } else if (data.status == 1) {
                        location.href = '/platform'
                            // ejs.render('info-build');
                    } else {
                        $('#loading').hide();
                        $('.upload-btn').show();
                        $('.progress').hide();
                        $('.form-group').find('.help-block').html(data.content);
                        $('.form-group').removeClass('has-success').addClass('has-error');

                    }
                },
                xhr: function() {
                    // create an XMLHttpRequest
                    var xhr = new XMLHttpRequest();
                    // listen to the 'progress' event
                    xhr.upload.addEventListener('progress', function(evt) {
                        if (evt.lengthComputable) {
                            // calculate the percentage of upload completed
                            var percentComplete = evt.loaded / evt.total;
                            percentComplete = parseInt(percentComplete * 100);
                            // update the Bootstrap progress bar with the new percentage
                            $('.progress-bar').text(percentComplete + '%');
                            $('.progress-bar').width(percentComplete + '%');
                            // once the upload reaches 100%, set the progress bar text to done
                            if (percentComplete === 100) {
                                $('#loading').show();
                                // $('#loading').text('Handling project');
                            }
                        }
                    }, false);
                    return xhr;
                }
            });
        }


    }
});